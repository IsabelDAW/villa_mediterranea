

<?php $__env->startSection('content'); ?>
<div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-4"><i class="fas fa-users-cog me-2"></i> Gestión de Usuarios</h2>
    <a href="<?php echo e(route('perfil')); ?>" 
   class="btn btn-dark border-white text-white px-4 shadow-sm d-inline-block">
   Volver
</a>
          
    </div>
    <div class="card shadow border-0">
        <div class="card-body p-0">
            <table class="table table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nombre Completo</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($u->id); ?></td>
                        <td><?php echo e($u->nombre); ?> <?php echo e($u->apellidos); ?></td>
                        <td><?php echo e($u->email); ?></td>
                        <td><?php echo e($u->telefono ?? 'No indicado'); ?></td>
                        <td>
                            <span class="badge <?php echo e($u->rol == 'admin' ? 'bg-danger' : 'bg-primary'); ?>">
                                <?php echo e(ucfirst($u->rol)); ?>

                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline-dark">
                             <a href="<?php echo e(route('perfil.edit', $u->id)); ?>">
                                <i class="fas fa-eye"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>