

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card shadow border-0">
        <div class="card-header bg-dark text-white p-4 d-flex justify-content-between align-items-center">
            <h3 class="mb-0">Mis Experiencias en la Villa</h3>
            <span class="badge bg-gold" style="background-color: #b89550;"><?php echo e(count($reservas)); ?> Reservas</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Fecha</th>
                            <th>Servicio / Experiencia</th>
                            <th>Personas</th>
                            <th>Total</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4">
                                    <strong><?php echo e(\Carbon\Carbon::parse($reserva->fecha_inicio)->format('d/m/Y')); ?></strong>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $reserva->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                            <?php echo e($detalle->servicio->nomServExp); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($reserva->n_personas); ?> pers.</td>
                                <td class="fw-bold"><?php echo e($reserva->precio); ?>€</td> 
                                <td class="text-center">

<button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#confirmarBorrado">
  Cancelar
</button>

<div class="modal fade" id="confirmarBorrado" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content bg-dark text-center">
      <div class="modal-header justify-content-center">
        <h5 class="modal-title bg-dark text-white text-center w-100" class=text-center>Confirmar Cancelación</h5>
      </div>

      <div class="modal-body bg-light" >
        ¿Estás seguro de que deseas cancelar la reserva en Villa Mediterránea?
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Volver</button>

    <form action="<?php echo e(route('reserva.destroy', $reserva->id_reserva)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?> <!-- Laravel cuando recibe el formulario y ve este metodo directamente 
            busca la ruta delete y ejecuta la funcion que se encuentra en el controlador.-->
            <button type="submit" class="btn btn-danger">Sí, cancelo</button>
        
       
    </form>
                              
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    <i class="fas fa-calendar-times display-4 d-block mb-3"></i>
                                    Aún no has realizado ninguna reserva.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="mt-4">
        <a href="<?php echo e(route('perfil')); ?>" class="btn btn-dark text-white text-decoration-none">
            <i class="fas fa-arrow-left me-2"></i> Volver a mi Perfil
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/reservas/index.blade.php ENDPATH**/ ?>