

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between mb-3">
        <h2>Gestión de Servicios y Experiencias</h2>
        <a href="<?php echo e(route('admin.servicios.create')); ?>" class="btn btn-primary">+ Nuevo</a>
    </div>

    <table class="table table-hover bg-white shadow-sm">
        <thead class="table-dark">
            <tr>
                <th>Nombre</th>
                <th>Tipo</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $elementos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->nomServExp); ?></td>
                <td><?php echo e($item->tipo == 's' ? 'Servicio' : 'Experiencia'); ?></td>
                <td><small><?php echo e($item->imagen); ?></small></td>
                <td>
                    <a href="<?php echo e(route('admin.servicios.edit', $item->id_servExp)); ?>" class="btn btn-sm btn-warning">
                        <i class="fas fa-edit"></i> Modificar
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/admin/servicios/index.blade.php ENDPATH**/ ?>