


<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-uppercase" style="font-size: 1.5rem;">
            <i class="fas fa-key text-warning me-2"></i> Gestión Global de Reservas
        </h2>
        <a href="<?php echo e(route('perfil')); ?>" class="btn btn-dark">Volver</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th class="ps-4">Cliente</th>
                        <th>Experiencia</th>
                        <th>Fecha y Hora</th>
                        <th>Personas</th>
                        <th>Total</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-4">
                            <strong><?php echo e($reserva->user->nombre); ?></strong><br>
                            <small class="text-muted"><?php echo e($reserva->user->email); ?></small>
                        </td>
                        <td>
                            <span class="badge bg-secondary">
                                <?php echo e($reserva->detalles->first()->servicio->nomServExp ?? 'N/A'); ?>

                            </span>
                        </td>
                        <td><?php echo e(\Carbon\Carbon::parse($reserva->fecha_reserva)->format('d/m/Y H:i')); ?></td>
                        <td class="text-center"><?php echo e($reserva->n_personas); ?></td>
                        <td class="fw-bold"><?php echo e(number_format($reserva->precio, 2)); ?>€</td>
                        <td class="text-center">

<button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#confirmarBorrado">
  Cancelar
</button>

<div class="modal fade" id="confirmarBorrado" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content bg-dark text-center">
      <div class="modal-header justify-content-center">
        <h5 class="modal-title bg-dark text-white text-center w-100" class=text-center>Confirmar Cancelación</h5>
      </div>

      <div class="modal-body bg-light" >
        ¿Estás seguro de que deseas cancelar la reserva en Villa Mediterránea?
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Volver</button>


                            <form action="<?php echo e(route('admin.reservas.destroy', $reserva->id_reserva)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>

             
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="fas fa-calendar-times display-4 d-block mb-3"></i>
                                    Aún no has realizado ninguna reserva.
                                </td>
                            </tr>
                        <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/admin/reservas/index.blade.php ENDPATH**/ ?>