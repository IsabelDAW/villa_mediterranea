 

<?php $__env->startSection('content'); ?>
<div class="py-3 py-md-5">
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-12 col-md-11 col-lg-8 col-xl-7 col-xxl-6">
                <div class="bg-white p-4 p-md-5 rounded shadow-sm">
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="text-center mb-5">
                                <h2 class="text-center" style="color: #2772c9; font-weight: bold;">Crear Cuenta</h2>
                            </div>
                        </div>
                    </div>
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('register')); ?>" method="POST" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?> <!--Sello de seguridad que le dice a laravel que el token es suyo-->

                        <div class="row gy-3 gy-md-4 overflow-hidden">
                            
                            <div class="col-12">
                           <label for="inputNombre" class="form-label">Nombre <span class="text-danger">*</span></label>
         <div class="input-group">
                          <span class="input-group-text"><i class="fas fa-user"></i></span>
                          
                        <input type="text" class="form-control" name="nombre" id="inputNombre" 
                        value="<?php echo e(old('apellidos')); ?>" required pattern="^[a-zA-ZÀ-ÿ\s']+$">
                       <div class="invalid-feedback">El nombre es obligatorio.</div>
            </div>
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-12">
                                <label for="inputApellidos" class="form-label">Apellidos <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="far fa-id-card"></i></span>
                                    <input type="text" class="form-control" name="apellidos" id="inputApellidos" value="<?php echo e(old('apellidos')); ?>" required 
               pattern="^[a-zA-ZÀ-ÿ\s']+$"> <div class="invalid-feedback">El apellido es oligatorio</div>
                                <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-12">
                                <label for="inputTelefono" class="form-label">Teléfono <span class="text-danger">*</span></label>
                                <div class="input-group">
                <span class="input-group-text"><i class="fas fa-phone-alt"></i></span>
                <input type="tel" class="form-control" name="telefono" id="inputTelefono" 
                       value="<?php echo e(old('telefono')); ?>" required 
                       pattern="^(\+[0-9]{1,4})?[0-9]{9}$">
                <div class="invalid-feedback">Introduce un teléfono válido (ej: +34 600000000).</div>
            </div>
                            </div>
                            
                            <div class="col-12">
                                <label for="inputEmail" class="form-label">Correo Electrónico <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" class="form-control" name="email" id="inputEmail" value="<?php echo e(old('email')); ?>" required>
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-12">
                               <label for="inputPassword" class="form-label">Contraseña <span class="text-danger">*</span></label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                <input type="password" class="form-control" name="password" id="inputPassword" 
                       required 
                       pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}">
                <div class="invalid-feedback">
                    Mínimo 8 caracteres, con mayúsculas, minúsculas, números y un símbolo.
                </div>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-12">
            <label for="inputPasswordConfirm" class="form-label">Repetir Contraseña 
                <span class="text-danger">*</span></label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-check-double"></i></span>
                <input type="password" class="form-control" name="password_confirmation" 
                id="inputPasswordConfirm" required>
                <div class="invalid-feedback">Las contraseñas no coinciden.</div>
            </div>
        </div>
                            
                            
                            <div class="col-12 mt-4">
                                <div class="d-grid">
                                    <button class="btn btn-primary btn-lg" type="submit">Registrarse</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/auth/register.blade.php ENDPATH**/ ?>