 

<?php $__env->startSection('content'); ?>


    <div id="carouselExampleFade" class="carousel slide carousel-fade mx-4" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            
            <button type="button" data-bs-target="#carouselExampleFade" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Boda"></button>
            <button type="button" data-bs-target="#carouselExampleFade" data-bs-slide-to="1" aria-label="Buceo"></button>
            <button type="button" data-bs-target="#carouselExampleFade" data-bs-slide-to="2" aria-label="Kayac"></button>
        </div>

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e(asset('img/servicios/boda.png')); ?>" class="d-block w-100 kenburns" alt="wedding planner">
                <div class="carousel-caption d-flex flex-column justify-content-center h-100">
                    <h3 class="fw-bold">Wedding planner</h3>
                    <p>Haz realidad el día más importante de tu vida con nuestro servicio de wedding planner: cada rincón de la villa se transforma en el escenario perfecto para tu historia de amor.</p>
                </div>
            </div>

            <div class="carousel-item">
                <img src="<?php echo e(asset('img/servicios/masaje.png')); ?>" class="d-block w-100 kenburns" alt="Masajes en la villa">
                <div class="carousel-caption d-flex flex-column justify-content-center h-100">
                    <h3 class="fw-bold">Masajes en la villa</h3>
                    <p>Déjate envolver por la calma del Mediterráneo y renueva cuerpo y mente con nuestros masajes exclusivos.</p>
                </div>
            </div>

            <div class="carousel-item">
                <img src="<?php echo e(asset('img/servicios/campana.png')); ?>" class="d-block w-100 kenburns" alt="Mayordomo privado">
                <div class="carousel-caption d-flex flex-column justify-content-center h-100">
                    <h3 class="fw-bold">Mayordomo privado en la villa</h3>
                    <p>Disfruta de la exclusividad de un mayordomo privado que cuida cada detalle para que tu estancia sea perfecta.</p>
                </div>
            </div>
        </div>


        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Anterior</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Siguiente</span>
        </button>
    </div>

    
    <div class="row row-cols-1 row-cols-md-3 g-4 mt-4 mx-4 text-center">
    
        
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card h-100 d-flex flex-column">
                    
<img src="<?php echo e(asset('img/servicios/' . $servicio->imagen)); ?>" class="card-img-top" alt="<?php echo e($servicio->nomServExp); ?>">
                    
                    <div class="card-body d-flex flex-column">
                        
                        <h5 class="card-title"><?php echo e($servicio->nomServExp); ?></h5>
                        <p class="card-text"><?php echo e($servicio->descripcion); ?></p>
                        
           <div class="mt-auto mb-3">
        <hr>
        <div class="d-flex justify-content-between align-items-center">
            <span class="text-muted">Precio por persona:</span>
            <span class="h5 fw-bold text-success mb-0"><?php echo e(number_format($servicio->precio, 2, ',', '.')); ?>€</span>
        </div>    
           </div>
                                   <div class="mt-auto">


           <!---*********************PARA RECOGER LA RESERVA******************************************************************---->

<?php if(auth()->guard()->check()): ?>
           <form action="<?php echo e(route('reservas.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        
            <input type="hidden" name="servicio_id" value="<?php echo e($servicio->id_servExp); ?>">
                       
                    
                        <div class="mb-2">
<label class=" fw-bold text-secondary mb-1 d-block text-center">
        ¿Cuántos asistentes disfrutarán el servicio?
    </label>                          
      <input type="number" name="personas" class="form-control form-control-sm text-center" value="1" min="1" max="20" 
                             onkeydown="return false;" style="caret-color: transparent; cursor: default;"required>
                        </div>

                        
                        <button type="submit" class="btn btn-primary w-100">Reservar Ahora</button>
                    </form>
                    <?php else: ?>
                        
                        <div class="text-center">
                            <p class="small text-danger">Inicia sesión para reservar</p>
                            <!--
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary w-100">
                                <i class="fas fa-sign-in-alt me-1"></i> Reservar
                            </a>
                            --->
                            <a href="#" class="btn btn-outline-primary w-100" data-bs-toggle="modal" data-bs-target="#loginModal">
    <i class="fas fa-sign-in-alt me-1"></i> Reservar
</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



            <div class="card text-center mt-4 mx-4 custom-card">
  <div class="card-header">
    <strong> Haz tuya la villa: reserva servicios privados y exclusivos. </strong>
</div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <p><strong>“El lujo es una experiencia que te transforma.”</strong></p>
    </blockquote>
  </div>
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/pages/servicios.blade.php ENDPATH**/ ?>