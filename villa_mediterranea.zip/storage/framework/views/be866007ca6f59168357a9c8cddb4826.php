

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white">
                    <h4 class="mb-0">
                        <?php echo e(isset($elemento) ? 'Modificar Elemento' : 'Crear Nuevo Servicio/Experiencia'); ?>

                    </h4>
                </div>
                <div class="card-body p-4">
                    <form action="<?php echo e(route('admin.servicios.store')); ?>" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        
                        
                        <?php if(isset($elemento)): ?>
                            <input type="hidden" name="id_servExp" value="<?php echo e($elemento->id_servExp); ?>">
                        <?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nombre del Servicio o Experiencia</label>
                            <input type="text" name="nomServExp" class="form-control" 
                                   value="<?php echo e($elemento->nomServExp ?? old('nomServExp')); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Tipo de Categoría</label>
                            <select name="tipo" class="form-select" required>
                                <option value="" disabled <?php echo e(!isset($elemento) ? 'selected' : ''); ?>>Selecciona una opción...</option>
                                <option value="s" <?php echo e((isset($elemento) && $elemento->tipo == 's') ? 'selected' : ''); ?>>Servicio (s)</option>
                                <option value="e" <?php echo e((isset($elemento) && $elemento->tipo == 'e') ? 'selected' : ''); ?>>Experiencia (e)</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nombre del archivo de imagen</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-image"></i></span>
                                <input type="file" name="imagen" class="form-control" accept="image/*"
                                       placeholder="ejemplo: yate.png" 
                                       value="<?php echo e($elemento->imagen ?? old('imagen')); ?>">
                            </div>
                            <small class="text-muted">Por favor, selecciona un archivo.</small>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">Descripción</label>
                            <textarea name="descripcion" class="form-control" rows="4"><?php echo e($elemento->descripcion ?? old('descripcion')); ?></textarea>
                        </div>

                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Precio</label>
                            <input name="precio" class="form-control" rows="4" value= "<?php echo e($elemento->precio ?? old('precio')); ?>" required>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('admin.servicios.index')); ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Volver
                            </a>
                            <button type="submit" class="btn btn-primary px-5">
                                <i class="fas fa-save"></i> <?php echo e(isset($elemento) ? 'Guardar Cambios' : 'Crear Elemento'); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\villa_mediterranea\resources\views/admin/servicios/form.blade.php ENDPATH**/ ?>